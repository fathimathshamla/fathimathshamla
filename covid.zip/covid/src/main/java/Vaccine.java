
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;


/**
 * Servlet implementation class Appointment
 */
@WebServlet("/Vaccine")
public class Vaccine extends HttpServlet {

	@Override
	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String a=req.getParameter("t1");
		String b=req.getParameter("t2");
		String c=req.getParameter("t3");
		String d=req.getParameter("t4");
		String e=req.getParameter("t5");
		String f=req.getParameter("t6");
		String g=req.getParameter("t7");
		String h=req.getParameter("t8");
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		 PreparedStatement ps=con.prepareStatement("insert into vaccine values(?,?,?,?,?,?,?,?)");
		    ps.setString(1,a);
		    ps.setString(2,b);
		    ps.setString(3,c);
		    ps.setString(4,d);
		    ps.setString(5,e);
		    ps.setString(6,f);
		    ps.setString(7,g);
		    ps.setString(8,h);
		    ps.execute();
		    res.sendRedirect("index2.html");
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}		}	
	}
	