import javax.servlet.*;
import java.io.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/registration1")
public class registration1 extends HttpServlet {
	@Override
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		try
		{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		Statement st1=con.createStatement();
		ResultSet rs=st1.executeQuery("select * from registration");               

		pw.println("<html><body><h2>Registration Report</h2><hr>");
		pw.println("<hr></br><table cellspacing='0' cellpadding='5' border='1'>");
		pw.println("<tr>");
		pw.println("<td><b>Name</b></td>");
		pw.println("<td><b>Email</b></td>");
		pw.println("<td><b>Phoneno</b></td>");
		pw.println("<td><b>Gender</b></td>");
		pw.println("<td><b>Password</b></td>");
		pw.println("<td><b>Confirm Password</b></td>");
		pw.println("</tr>");
		while(rs.next()) 
		{
			pw.println("<tr>");
			pw.println("<td>"+rs.getString(1) + "</td>");
			pw.println("<td>"+rs.getString(2) + "</td>");
			pw.println("<td>"+rs.getString(3) + "</td>");
			pw.println("<td>"+rs.getString(4) + "</td>");
			pw.println("<td>"+rs.getString(5) + "</td>");
			pw.println("<td>"+rs.getString(6) + "</td>");
			pw.println("</tr>");
		}
		pw.println("</table></br><hr></body></html>");
	}		
catch(Exception ae)
{
	ae.printStackTrace();
}		}		}