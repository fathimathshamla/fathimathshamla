
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;


/**
 * Servlet implementation class Appointment
 */
@WebServlet("/Registration ")
public class Registration extends HttpServlet {

	@Override
	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String a=req.getParameter("t1");
		String b=req.getParameter("t2");
		String c=req.getParameter("t3");
		String d=req.getParameter("t4");
		String e=req.getParameter("t5");
		String f=req.getParameter("t6");
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		 PreparedStatement ps=con.prepareStatement("insert into registration  values(?,?,?,?,?,?)");
		    ps.setString(1,a);
		    ps.setString(2,b);
		    ps.setInt(3,Integer.parseInt(c));
		    ps.setString(4,d);
		    ps.setString(5,e);
		    ps.setString(6,f);
		    ps.execute();
		    pw.print("<h1>Appointment Details</h1><hr>");
			pw.print("Name : "+a);
			pw.println("<br><br>");
			pw.print("Email : "+b);
			pw.println("<br><br>");
			pw.print("Age : "+c);
			pw.println("<br><br>");
			pw.print("Department : "+d);
			pw.println("<br><br>");
			pw.print("Gender : "+e);
			pw.println("<br><br>");
			pw.print("Phone number : "+f);
			pw.println("<br><br>");
			
			pw.print("Your Registration is successful");
			res.sendRedirect("login.html");
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}		}	
	}
	